from setuptools import setup
setup(
    name="miFuncion",
    version="1.0",
    description="realiza sumas y comprueba si es par impar",
    author="Jose",
    author_email="ticoticotaa@gmail.com",
    url="https://wwww.ticoticotaa.es",
    packages=["paquetes"]
)
